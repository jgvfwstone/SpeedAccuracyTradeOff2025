% combine2025_v5ForPublcattion.m code for paper submission. This just reads
% data summay and plots graphs.

% README: Set resultspath variable below to point to data folder.

clear all;
warning off;
global  AoverK RTmeanresidual PSE logliksrecord ;

findRTorYNorBOTHorCOMBINED=0;
% AoverK = params(1);
% RTmeanresidual = params(2);
% PSE = params(3);
% K = params(4);
% varP = params(5);
% varRT = params(6);
% covarRTP = params(7);
% varx = params(8);
% xRT = params(9);

ntrialsperstimulusstrength = 20;
nsubjects=15;
findRTorYNorBOTHorCOMBINED=3;

results=[];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pliks=[]; liks=[];
for ii= 1:nsubjects
    observerID=ii;

    % load data for publication.
    resultspath= '/Users/jamesvstone/Documents/PAPERS_mac/combineRTandBinary2024/CodeDataForPublication/DataForPublication2025A' ;

    %resultspath = '../DataForPublication2025A';
    eval(['cd ' resultspath]);

    fname = ['resultobs' num2str(observerID) '.mat']
    eval(['load ' fname]);

    fprintf('fname=%s\n',fname);

    %[corrRT corrBinary corrx]=plotModelRTandP_v1(qrt,params,105);

    result=[A K R  maxbitspersecond T RTdatT k];
    result(3)=R;
    results=[results; result];

    %minusloglik = JVS_get_minusloglik_cov2024a(params,qrt);

end % observer

As = results(:,1);
results(:,3) = 1./As.^2;
thresh=results(:,5);
R=results(:,3);

figure(1);
plot(thresh,R,'*');

[b yhat noise]=jregress_simpleA(R,thresh,1,109);
m=b(1);
c=b(2);
xlabel('Threshold');
ylabel('R (bits/s)');
%jset_xlim(0.0,1.05*max(thresh));
kk=29;
%jset_ylim(4,kk);

return
%%%%%%%%%%%%%%%%%%%%%%%%%%