function [b yhat ynoise]= jregress_simple(y,x,addbias,fignum)
% y must be a column vector of n rows, X should be nxp
% regress x against dependent var y.

% eg n = 21; x = randn(n,1); ynoise = rand(n,1)*0.5; y = 2*x+ynoise + 3;
% [b yhat  ynoise]= jregress_simple(y,x,1) % b=[2 3]' = [slope intercept]

if nargin<4
    fignum=18;
end

y=makecolvec(y);
x=makecolvec(x);
[n p]=size(x);

if addbias
    X = [x ones(n,1) ];
else
    X=x;
end

b = X\y;
m=b(1); % slope
c=b(2); % intercept

% find x given xhat where xhat is based on EPRD model.
yhat = m*x + c; % noiseless y.
ynoise = yhat-y; % noise in x.

figure(fignum); clf;
plot(x,y,'*',x,yhat); jsetfig;
title('jregress\_simple'); grid on;

% [r p]=jcorr( x , y );
% fprintf('\nCorrelation: r=%.3f p=%.3f\n',r,p);
fprintf('Regression: Slope m=%.3f, intercept c=%.3f.\n',m,c);


